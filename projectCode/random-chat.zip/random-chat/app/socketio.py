from flask_socketio import SocketIO

socketio = SocketIO(max_http_buffer_size=13500000)